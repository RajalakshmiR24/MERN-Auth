import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axiosInstance from '../services/axiosInstance';

const SuccessPage = () => {
  const navigate = useNavigate();
  const [username, setUsername] = useState('');

  useEffect(() => {
    const fetchUserDetails = async () => {
      try {
        const response = await axiosInstance.get('/api/user/profile');
        console.log("Profile data received:", response.data); // Log the full response to inspect data
        setUsername(response.data.username);
      } catch (error) {
        console.error('Error fetching user details:', error);
        alert('Failed to fetch user details. Please try again.');
      }
    };

    fetchUserDetails(); // Fetch user details when component mounts
  }, []);

  console.log("Username in state:", username); // Log the username to ensure it's being updated

  const handleLogout = () => {
    localStorage.removeItem('accessToken');
    localStorage.removeItem('refreshToken');
    alert('Logged out successfully');
    navigate('/login');
  };

  const handleView = () => {
    navigate('/user-details', { state: { username } }); // Navigate to the new component and pass username
  };

  return (
    <div>
      <h1>Login Successful!</h1>
      {username ? <h2>Welcome, {username}!</h2> : <p>Loading user details...</p>}
      <button onClick={handleLogout}>Logout</button>
      {/* Add the View button */}
      {username && <button onClick={handleView}>View Username</button>}
    </div>
  );
};

export default SuccessPage;
