import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

const UserDetails = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { username } = location.state || {}; // Get username from navigation state

  const handleBack = () => {
    navigate(-1); // Navigate back to the previous page
  };

  return (
    <div>
      <h1>User Details</h1>
      {username ? (
        <h2>Username: {username}</h2>
      ) : (
        <p>No user details available.</p>
      )}
      <button onClick={handleBack}>Go Back</button>
    </div>
  );
};

export default UserDetails;
