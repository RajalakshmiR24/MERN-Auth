import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Register from './components/Register';
import Login from './components/Login';
import SuccessPage from './components/SuccessPage'; // Import the SuccessPage component
import UserDetails from './components/UserDetails';

const App = () => {
  return (
    <Router>
      <div>
        
        <Routes>
        <Route path="/login" element={<Login />} />
          <Route path="/" element={<Register />} />
          <Route path="/success" element={<SuccessPage />} />
          <Route path="/user-details" element={<UserDetails />}/>
        </Routes>
      </div>
    </Router>
  );
};

export default App;
