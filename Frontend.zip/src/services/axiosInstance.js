import axios from 'axios';

const axiosInstance = axios.create({
  baseURL: 'http://localhost:5000',
});

// Attach the access token to every request
axiosInstance.interceptors.request.use(
  (config) => {
    const accessToken = localStorage.getItem('accessToken');
    if (accessToken) {
      config.headers.Authorization = `Bearer ${accessToken}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Handle responses and check for token expiration
axiosInstance.interceptors.response.use(
  (response) => {
    return response;
  },
  async (error) => {
    // Check if the error response indicates a token expiration
    if (error.response?.status === 401 && error.response.data.message === 'Token has expired, please login again') {
      // Alert the user that the session has expired
      alert('Your session has expired. Please log in again.');

      // Clear the tokens from local storage
      localStorage.removeItem('accessToken');
      localStorage.removeItem('refreshToken');

      // Redirect the user to the login page
      window.location.href = '/login';  // Use window.location.href to navigate since interceptors are outside React
    }

    return Promise.reject(error);
  }
);

export default axiosInstance;
