const jwt = require('jsonwebtoken');

// Generate Access Token
const generateAccessToken = (user) => {
  return jwt.sign({ id: user._id, username: user.username }, process.env.ACCESS_TOKEN_SECRET, {
    expiresIn: '1m', // Access token valid for 1 minute
  });
};

// Generate Refresh Token
const generateRefreshToken = (user) => {
  return jwt.sign({ id: user._id, username: user.username }, process.env.REFRESH_TOKEN_SECRET, {
    expiresIn: '7d', // Refresh token valid for 7 days
  });
};

module.exports = { generateAccessToken, generateRefreshToken };
