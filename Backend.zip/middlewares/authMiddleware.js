const jwt = require('jsonwebtoken');

const authMiddleware = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1]; // Extract the token from the Authorization header

  if (!token) {
    return res.status(200).json({ code: 401, message: 'No token provided' });
  }

  jwt.verify(token, process.env.ACCESS_TOKEN_SECRET, (err, user) => {
    if (err) {
      if (err.name === 'TokenExpiredError') {
        // Token has expired
        return res.status(401).json({ code: 401, message: 'Token has expired, please login again' });
      }
      // Other token errors
      return res.status(200).json({ code: 403, message: 'Invalid token' });
    }

    req.user = user; // Attach user data to the request
    next();
  });
};

module.exports = authMiddleware;
