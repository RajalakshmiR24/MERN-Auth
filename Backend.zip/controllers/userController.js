// Handle fetching the profile information
exports.getProfile = (req, res) => {
    try {
      console.log("User profile request received:", req.user); // Check if user details are coming through
      res.status(200).json({ code: 200, message: `Welcome, ${req.user.username}`, username: req.user.username });
    } catch (error) {
      console.error("Error fetching profile:", error);
      res.status(200).json({ code: 500, message: 'Server error' });
    }
  };
  