const User = require('../models/User');
const jwt = require('jsonwebtoken');
const { generateAccessToken, generateRefreshToken } = require('../utils/token');

// Register User
exports.register = async (req, res) => {
  const { username, password } = req.body;
  try {
    const userExists = await User.findOne({ username });
    if (userExists) {
      return res.status(200).json({ code: 400, message: 'User already exists' });
    }

    const user = await User.create({ username, password });
    res.status(200).json({ code: 201, message: 'User created successfully', userId: user._id });
  } catch (error) {
    console.error(error);
    res.status(200).json({ code: 500, message: 'Server error' });
  }
};

// Login User
exports.login = async (req, res) => {
  const { username, password } = req.body;
  try {
    const user = await User.findOne({ username });
    if (!user || !(await user.matchPassword(password))) {
      return res.status(200).json({ code: 401, message: 'Invalid credentials' });
    }

    const accessToken = generateAccessToken(user);
    const refreshToken = generateRefreshToken(user);

    res.status(200).json({ accessToken, refreshToken });
  } catch (error) {
    console.error(error);
    res.status(200).json({ code: 500, message: 'Server error' });
  }
};

// Token refresh
exports.refreshToken = (req, res) => {
  const { token } = req.body;

  if (!token) {
    return res.status(200).json({ code: 401, message: 'No token provided' });
  }

  jwt.verify(token, process.env.REFRESH_TOKEN_SECRET, (err, user) => {
    if (err) {
      return res.status(200).json({ code: 403, message: 'Invalid refresh token' });
    }

    const accessToken = generateAccessToken({ id: user.id, username: user.username });
    res.status(200).json({ accessToken });
  });
};
